import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import { Features } from './Features/Features';
import { Frame17Icon } from './Frame17Icon.js';
import { Frame18Icon } from './Frame18Icon.js';
import { Frame19Icon } from './Frame19Icon.js';
import { Frame20Icon } from './Frame20Icon.js';
import { Frame46Icon } from './Frame46Icon.js';
import { Frame47Icon } from './Frame47Icon.js';
import { Frame48Icon } from './Frame48Icon.js';
import { Frame49Icon } from './Frame49Icon.js';
import { Frame50Icon } from './Frame50Icon.js';
import { Frame51Icon } from './Frame51Icon.js';
import { Frame52Icon } from './Frame52Icon.js';
import { Frame53Icon } from './Frame53Icon.js';
import { Frame54Icon } from './Frame54Icon.js';
import { IconUserEditIcon } from './IconUserEditIcon.js';
import classes from './LoginPage.module.css';
import { Nav_Bar } from './Nav_Bar/Nav_Bar';
import { PrimaryIcon } from './PrimaryIcon.js';
import { VectorIcon } from './VectorIcon.js';

interface Props {
  className?: string;
}
/* @figmaId 201:116 */
export const LoginPage: FC<Props> = memo(function LoginPage(props = {}) {
  return (
    <div className={`${resets.storybrainResets} ${classes.root}`}>
      <div className={classes.insight}>
        <Features
          className={classes.features}
          classes={{
            frame18: classes.frame18,
            frame19: classes.frame19,
            frame20: classes.frame20,
            frame17: classes.frame17,
          }}
          swap={{
            vector: <VectorIcon className={classes.icon} />,
            frame18: (
              <div className={classes.frame18}>
                <Frame18Icon className={classes.icon2} />
              </div>
            ),
            frame19: (
              <div className={classes.frame19}>
                <Frame19Icon className={classes.icon3} />
              </div>
            ),
            frame20: (
              <div className={classes.frame20}>
                <Frame20Icon className={classes.icon4} />
              </div>
            ),
          }}
        />
      </div>
      <Nav_Bar
        className={classes.nav_Bar}
        classes={{ hUSHH1: classes.hUSHH1, lgnbtn: classes.lgnbtn, supbtn: classes.supbtn }}
      />
      <div className={classes.loginPlusRegister}>
        <div className={classes.loginInBox}>
          <div className={classes.rectangle44}></div>
          <div className={classes.rectangle45}></div>
          <div className={classes.rectangle46}></div>
          <div className={classes.rectangle47}></div>
          <div className={classes.frame42}>
            <div className={classes.username}>Username / Email</div>
          </div>
          <div className={classes.frame43}>
            <div className={classes.password}>Password</div>
          </div>
          <div className={classes.logIn}>Log In</div>
          <div className={classes.primary}>
            <PrimaryIcon className={classes.icon5} />
          </div>
          <div className={classes.IconUserEdit}>
            <IconUserEditIcon className={classes.icon6} />
          </div>
        </div>
        <div className={classes.frame45}>
          <div className={classes.donTHaveAnAccountSignUp}>
            <p className={classes.labelWrapper}>
              <span className={classes.label}>Don’t have an account? </span>
              <span className={classes.label2}>Sign Up</span>
            </p>
          </div>
        </div>
      </div>
      <div className={classes.frame61}>
        <div className={classes.frame172}>
          <Frame17Icon className={classes.icon7} />
        </div>
        <div className={classes.signUpWith}>Sign Up With</div>
      </div>
      <div className={classes.frame60}>
        <div className={classes.rectangle42}></div>
      </div>
      <div className={classes.frame59}>
        <div className={classes.rectangle442}></div>
      </div>
      <div className={classes.frame58}>
        <div className={classes.rectangle43}></div>
      </div>
      <div className={classes.frame57}>
        <div className={classes.rectangle452}></div>
      </div>
      <div className={classes.frame56}>
        <div className={classes.rectangle472}></div>
      </div>
      <div className={classes.frame55}>
        <div className={classes.rectangle462}></div>
      </div>
      <div className={classes.frame54}>
        <Frame54Icon className={classes.icon8} />
      </div>
      <div className={classes.frame53}>
        <Frame53Icon className={classes.icon9} />
      </div>
      <div className={classes.frame52}>
        <Frame52Icon className={classes.icon10} />
      </div>
      <div className={classes.frame51}>
        <Frame51Icon className={classes.icon11} />
      </div>
      <div className={classes.frame50}>
        <Frame50Icon className={classes.icon12} />
      </div>
      <div className={classes.frame49}>
        <Frame49Icon className={classes.icon13} />
      </div>
      <div className={classes.frame48}>
        <Frame48Icon className={classes.icon14} />
      </div>
      <div className={classes.frame47}>
        <Frame47Icon className={classes.icon15} />
      </div>
      <div className={classes.frame46}>
        <Frame46Icon className={classes.icon16} />
      </div>
    </div>
  );
});
