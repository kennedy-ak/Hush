import { memo } from 'react';
import type { FC } from 'react';

import resets from '../../_resets.module.css';
import { Nav_Bar2 } from '../Nav_Bar2/Nav_Bar2';
import classes from './Nav_Bar.module.css';

interface Props {
  className?: string;
  classes?: {
    hUSHH1?: string;
    lgnbtn?: string;
    supbtn?: string;
    root?: string;
  };
}
/* @figmaId 195:94 */
export const Nav_Bar: FC<Props> = memo(function Nav_Bar(props = {}) {
  return (
    <div className={`${resets.storybrainResets} ${props.classes?.root || ''} ${props.className || ''} ${classes.root}`}>
      <Nav_Bar2
        className={classes.nav_Bar}
        classes={{
          hUSHH1: `${props.classes?.hUSHH1 || ''} ${classes.hUSHH1}`,
          lgnbtn: `${props.classes?.lgnbtn || ''} ${classes.lgnbtn}`,
          supbtn: `${props.classes?.supbtn || ''} ${classes.supbtn}`,
        }}
      />
    </div>
  );
});
