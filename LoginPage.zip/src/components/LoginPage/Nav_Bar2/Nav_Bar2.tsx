import { memo } from 'react';
import type { FC } from 'react';

import resets from '../../_resets.module.css';
import { Dashboard_buttonIcon } from './Dashboard_buttonIcon.js';
import classes from './Nav_Bar2.module.css';
import { SearchIcon } from './SearchIcon.js';

interface Props {
  className?: string;
  classes?: {
    hUSHH1?: string;
    lgnbtn?: string;
    supbtn?: string;
    root?: string;
  };
}
/* @figmaId 160:136 */
export const Nav_Bar2: FC<Props> = memo(function Nav_Bar2(props = {}) {
  return (
    <div className={`${resets.storybrainResets} ${props.classes?.root || ''} ${props.className || ''} ${classes.root}`}>
      <div className={classes.navigation_Box}></div>
      <div className={classes.nav_Links}>
        <div className={classes.links}>
          <div className={classes.blog}>Blog</div>
          <div className={classes.about}>About</div>
          <div className={classes.contact}>Contact</div>
        </div>
      </div>
      <div className={classes.hush_Logo}>
        <div className={`${props.classes?.hUSHH1 || ''} ${classes.hUSHH1}`}></div>
      </div>
      <div className={classes.dashboard_Button}>
        <Dashboard_buttonIcon className={classes.icon} />
      </div>
      <div className={classes.logo_Name}>
        <div className={classes.hUSH}>HUSH</div>
      </div>
      <div className={classes.searchPane}>
        <div className={classes.search}>
          <SearchIcon className={classes.icon2} />
        </div>
        <div className={classes.search2}>Search</div>
      </div>
      <div className={classes.login_Button}>
        <div className={`${props.classes?.lgnbtn || ''} ${classes.lgnbtn}`}>
          <div className={classes.btn}></div>
          <div className={classes.login}>Login</div>
        </div>
      </div>
      <div className={classes.loginIn_Button}>
        <div className={`${props.classes?.supbtn || ''} ${classes.supbtn}`}>
          <button className={classes.signUp_Button}>
            <div className={classes.signUp}>Sign Up</div>
          </button>
        </div>
      </div>
    </div>
  );
});
