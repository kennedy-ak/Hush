import { memo, SVGProps } from 'react';

const Dashboard_buttonIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 40 30' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path d='M0 0V4.30416H40V0H0ZM0 12.7834V17.0875H40V12.7834H0ZM0 25.6958V30H40V25.6958H0Z' fill='black' />
  </svg>
);
const Memo = memo(Dashboard_buttonIcon);
export { Memo as Dashboard_buttonIcon };
