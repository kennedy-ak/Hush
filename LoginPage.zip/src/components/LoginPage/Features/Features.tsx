import { memo } from 'react';
import type { FC, ReactNode } from 'react';

import resets from '../../_resets.module.css';
import classes from './Features.module.css';
import { Frame18Icon } from './Frame18Icon.js';
import { Frame19Icon } from './Frame19Icon.js';
import { Frame20Icon } from './Frame20Icon.js';
import { VectorIcon } from './VectorIcon.js';

interface Props {
  className?: string;
  classes?: {
    frame18?: string;
    frame19?: string;
    frame20?: string;
    frame17?: string;
    root?: string;
  };
  swap?: {
    vector?: ReactNode;
    frame18?: ReactNode;
    frame19?: ReactNode;
    frame20?: ReactNode;
  };
}
/* @figmaId 116:116 */
export const Features: FC<Props> = memo(function Features(props = {}) {
  return (
    <div className={`${resets.storybrainResets} ${props.classes?.root || ''} ${props.className || ''} ${classes.root}`}>
      <div className={classes.vector}>{props.swap?.vector || <VectorIcon className={classes.icon} />}</div>
      <div className={`${props.classes?.frame18 || ''} ${classes.frame18}`}>
        {props.swap?.frame18 || <Frame18Icon className={classes.icon2} />}
      </div>
      <div className={`${props.classes?.frame19 || ''} ${classes.frame19}`}>
        {props.swap?.frame19 || <Frame19Icon className={classes.icon3} />}
      </div>
      <div className={`${props.classes?.frame20 || ''} ${classes.frame20}`}>
        {props.swap?.frame20 || <Frame20Icon className={classes.icon4} />}
      </div>
      <div className={`${props.classes?.frame17 || ''} ${classes.frame17}`}>
        <div className={classes.getUnstuckAskAQuestionUnlockNe}>
          <div className={classes.textBlock}> Get Unstuck - ask a question</div>
          <div className={classes.textBlock2}>
            <p></p>
          </div>
          <div className={classes.textBlock3}>
            <p></p>
          </div>
          <div className={classes.textBlock4}>Unlock new privileges like following</div>
          <div className={classes.textBlock5}>
            <p></p>
          </div>
          <div className={classes.textBlock6}>
            <p></p>
          </div>
          <div className={classes.textBlock7}>Save your favorite tags, filters, and jobs</div>
          <div className={classes.textBlock8}>
            <p></p>
          </div>
          <div className={classes.textBlock9}>
            <p></p>
          </div>
          <div className={classes.textBlock10}>Earn reputation and badges</div>
          <div className={classes.textBlock11}>
            <p></p>
          </div>
          <div className={classes.textBlock12}>
            <p></p>
          </div>
          <div className={classes.textBlock13}>
            <p></p>
          </div>
          <div className={classes.textBlock14}>Use the power of HUSH inside your organization.</div>
          <div className={classes.textBlock15}>Try a free trial of HUSH for Teams. </div>
        </div>
      </div>
    </div>
  );
});
