import { memo, SVGProps } from 'react';

const Frame20Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 17 18' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M4.05056 8V4C4.05056 2.93913 4.47199 1.92172 5.22213 1.17157C5.97228 0.421427 6.9897 0 8.05056 0C9.11143 0 10.1288 0.421427 10.879 1.17157C11.6291 1.92172 12.0506 2.93913 12.0506 4M8.05056 12V14M2.05056 18H14.0506C14.581 18 15.0897 17.7893 15.4648 17.4142C15.8398 17.0391 16.0506 16.5304 16.0506 16V10C16.0506 9.46957 15.8398 8.96086 15.4648 8.58579C15.0897 8.21071 14.581 8 14.0506 8H2.05056C1.52013 8 1.01142 8.21071 0.636348 8.58579C0.261276 8.96086 0.0505621 9.46957 0.0505621 10V16C0.0505621 16.5304 0.261276 17.0391 0.636348 17.4142C1.01142 17.7893 1.52013 18 2.05056 18Z'
      stroke='black'
      strokeWidth={2}
      strokeLinecap='round'
      strokeLinejoin='round'
    />
  </svg>
);
const Memo = memo(Frame20Icon);
export { Memo as Frame20Icon };
