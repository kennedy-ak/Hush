import { memo, SVGProps } from 'react';

const Frame50Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 30 30' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M15 10L15.8286 13.2793L18.9092 11.8826L16.8619 14.575L19.8746 16.1126L16.4932 16.1908L17.1694 19.5048L15 16.9098L12.8306 19.5048L13.5068 16.1908L10.1254 16.1126L13.1381 14.575L11.0908 11.8826L14.1714 13.2793L15 10Z'
      fill='black'
    />
    <path
      d='M15 10L15.8286 13.2793L18.9092 11.8826L16.8619 14.575L19.8746 16.1126L16.4932 16.1908L17.1694 19.5048L15 16.9098L12.8306 19.5048L13.5068 16.1908L10.1254 16.1126L13.1381 14.575L11.0908 11.8826L14.1714 13.2793L15 10Z'
      fill='#E11FCE'
    />
  </svg>
);
const Memo = memo(Frame50Icon);
export { Memo as Frame50Icon };
